<?php
session_start();
session_destroy();

?>
<script>
	alert("bye");
	window.location.href="index.html";
</script>
<?php 
 
include "conn.php";
session_start();
$msg="";

 if(isset($_POST['login'])){

     $username=$_POST['user'];
     $pass=$_POST['pass'];

$check=mysqli_query($conn, "SELECT * FROM students WHERE ref_no='$username' AND password='$pass'");

$num=mysqli_num_rows($check);

if($num >=1 ){

$_SESSION['user']=$username;


echo '<script>
alert ("Account Accepted! Welcome Users!");
window.location.href="../home/studentdashboard.php";
</script> ';




}else{

$msg="Wrong username or password!!";

}
}
?>
<!DOCTYPE html>  
 <html>  
 <head>  
      <meta charset="utf-8">  
      <meta name="viewport" content="width=device-width, initial-scale=1">  
      <link rel="stylesheet" type="text/css" href="index.css">  
          <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.2.0/css/all.css'>
<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.2.0/css/fontawesome.css'>
      <title>Login Page</title>  
 </head>  
 <body>  
<div class="logo">
<img src="3.png" width="125" height="125" alt="logo">
</div>
<div class="name"> 
<h1>SENIOR HIGH SCHOOL</h1>
<h2>Students' Attendance Tracking System</h2>
</div>
<div class="container">
     <div class="screen">
          <div class="screen__content">
                              
                 <div class="login">     
               <form action="" method="POST">
                                   
                    <div class="login__user">  
                         <i class="login__icon fas fa-user"></i>
                         <input type="text" name="user" class="login__input" placeholder="Student Number" required autofocus>
                    </div>

                         
                   <div class="login__pass">  
                         <i class="login__icon fas fa-lock"></i>
                         <input type="password" name="pass" class="login__input" placeholder="Password" required>
                                   </div>

                    


                              
                   
                         <input type="submit" name="login" value="Login" class="login__submit">
                         
                 
                                   

                         <a href="#">Forgot Password</a>
                    <div class="error">
              
                                   
                          <div class="option-input" >                             
                              <h5> <?php echo $msg; ?></h5>
                              </div>
                             
                                          
                              </div>   
                                   
                              
                                              
                            
          </div>
</form>
</div>
          <div class="screen__background">
               <span class="screen__background__shape screen__background__shape4"></span>
               <span class="screen__background__shape screen__background__shape3"></span>      
               <span class="screen__background__shape screen__background__shape2"></span>
               <span class="screen__background__shape screen__background__shape1"></span>
          </div>         
     </div>

</div>
 </body>  
 </html>  
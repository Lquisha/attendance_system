function selectsubject(){

    var x = document.getElementById("subject").value;
    
    $.ajax({
        url:"showsub.php",
        method: "POST",
        data: {
            id : x
        },
         success:function(data){
            $("#ans").html(data);
         }
        })
}
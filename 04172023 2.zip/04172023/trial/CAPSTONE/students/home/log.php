<?php
include "conn.php";
session_start();

date_default_timezone_set('Asia/Manila');

$date = date("F d, Y");

if(empty($_SESSION)){
?>
  <script>
    alert("session expired");
    window.location.href="index.php";
  </script>
  <?php
}
else{
  $e=$_SESSION['user'];
  $get_student=mysqli_query($conn, "SELECT * FROM students WHERE ref_no='$e'");
  while($row=mysqli_fetch_object($get_student))
  {
    $studentid=$row -> ref_no;
    $fname=$row -> firstname;
    $card_num= $row -> card_no;
  }
}
?>
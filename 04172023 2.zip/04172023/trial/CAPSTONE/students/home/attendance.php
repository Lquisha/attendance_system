<?php 
  include "../login/conn.php";
 include "log.php";

  
  ?>

<!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>PHINMA University of ILoilo </title>
    <link rel="stylesheet" href="attendance.css">
    <script type="text/javascript" src="fetchDisp.js"></script>
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
<div class="sidebar">
    <div class="logo-details">
        <i class='bx bx-menu' id="btn" ></i>
			<div class="logo">
       <img src="2.png" alt="logo" height="180" width="180">
    </div>
     </div>
    <ul class="nav-list">
      <li>
        <a href="studentdashboard.php">
          <i class='bx bx-grid-alt'></i>
          <span class="links_name">Dashboard</span>
        </a>
         <span class="tooltip">Dashboard</span>
      </li>
     <li>
       <a href="#">
         <i class='bx bx-notepad' ></i>
         <span class="links_name">Attendance</span>
       </a>
       <span class="tooltip">Attendance</span>
     </li>
     <li>
       <a href="studentaccount.php">
         <i class='bx bx-mask' ></i>
         <span class="links_name">Account</span>
       </a>
       <span class="tooltip">Account</span>
     </li>
      <li class="log_out">
          <a href="logout.php">
            <i class='bx bx-log-out'></i>
            <span class="links_name">Log out</span>
          </a>
        </li>
      </ul>
  </div>
  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <span class="dashboard">View Attendance</span>
      </div>
   
      <div class="profile-details">
        <span class="admin_name"><?php echo $fname; ?><br><h4>student<h4></span>
      </div>
   
	 		
		 <img src="sun.png" id="icon">
		  
    </nav>
 
    <?php

$con = mysqli_connect ("localhost", "root", "", "attendance_system");
$sql ="SELECT subject FROM teachers";
$res = mysqli_query ($con, $sql);

?>
   
        
   <section class="home-content">
    <div class="dropdown" style="margin-top:-300px; margin-left:10px; ">

          Select Subject:
         <select id="subject" onchange="selectsubject()" style="background: #efefef; color:#000; border-radius: 12px;">
         <option  value="subject" selected></option>
        
        <?php while($rows = mysqli_fetch_array($res)){
        ?>
        <option value="<?php echo $rows ['subject']; ?>" > <?php echo $rows ['subject'] ;?></option>
        
        <?php
        }
        ?>
        
        </select>
      </div>
    <div class="table" style="margin-left:-270px;" >  
        <table class="content-table">
        
      <thead >
          <th> Name </th>
          <th> Date </th> 
          <th> Timein</th>
           <th> Timeout </th> 
           <th> Status </th>

      </thead> 
      </div>
<tbody id="ans">
       



          

       </tbody>
       </table>
      </div>


       </div>
          
   
      </section>
</section>

        

  <script>


   let sidebar = document.querySelector(".sidebar");
let closeBtn = document.querySelector("#btn");
let searchBtn = document.querySelector(".bx-search");

closeBtn.addEventListener("click", ()=>{
  sidebar.classList.toggle("active");
  menuBtnChange();//calling the function(optional)
});

searchBtn.addEventListener("click", ()=>{ // Sidebar open when you click on the search iocn
  sidebar.classList.toggle("active");
  menuBtnChange(); //calling the function(optional)
});

// following are the code to change sidebar button(optional)
function menuBtnChange() {
 if(sidebar.classList.contains("open")){
   closeBtn.classList.replace("bx-menu", "bx-menu-alt-right");//replacing the iocns class
 }else {
   closeBtn.classList.replace("bx-menu-alt-right","bx-menu");//replacing the iocns class
 }
}
var icon = document.getElementById("icon");

		icon.onclick = function(){
 	document.body.classList.toggle("dark-theme");
	if(document.body.classList.contains("dark-theme")){
  	icon.src = "sun.png";
		}else{
   icon.src = "moon.png";
	}
	
	}
	
	

</script>


 
</body>
</html>

<?php
$conn = mysqli_connect("localhost","root","","attendance_system");

?>
<?php
    include "log.php";

    $k = $_POST['id'];
    $k= trim($k);
    $con = mysqli_connect("localhost", "root", "", "attendance_system");
    $sql = "SELECT * FROM attendance WHERE subject='{$k}' and fname='$fname'";
    $res = mysqli_query($con, $sql);
    while($rows = mysqli_fetch_array($res)){
?>
    <tr> 
        <td><?php echo $rows ['fname']; ?> </td>
        <td> <?php echo $rows ['mydate' ]; ?> </td>
        <td> <?php echo $rows ['timein']; ?> </td>
        <td> <?php echo $rows [ 'timeout']; ?> </td>
        <td> <?php echo $rows ['status']; ?> </td>

    </tr>


<?php
   }
   echo $sql;

?>
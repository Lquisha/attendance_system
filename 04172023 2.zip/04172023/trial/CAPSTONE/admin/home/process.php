<?php
	include "conn.php";
	session_start();

		if(isset($_POST['submit'])){

			$address=$_POST['address'];
			$First_Name=$_POST['FN'];
			$Last_Name=$_POST['LN'];
			$Student_ID=$_POST['ID'];
			$Card_Number=$_POST['C'];
			$Section=$_POST['section'];
			$Year_Level=$_POST['YL'];
			$Contact_Number=$_POST['CN'];
			$Email=$_POST['email'];
			$Password=$_POST['pass'];

			$insertusers=mysqli_query($conn, "INSERT INTO students VALUES('0', '$Card_Number','$First_Name','$Last_Name','$address','$Section','$Year_Level','$Contact_Number','$Email','$Password','$Student_ID')");

			if($insertusers==true){
				echo '<script>
				alert ("Registration successful!");
				window.location.href="../home/adstudents.php";
				</script> ';
			}else{
				echo '<script>
				alert ("Registration unsuccessful!");
				window.location.href="../home/adstudents.php";
				</script> ';
			}
}

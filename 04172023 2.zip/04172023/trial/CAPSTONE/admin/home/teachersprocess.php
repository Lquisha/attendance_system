<?php
	
include "conn.php";
	session_start();
			if(isset($_POST['submit'])){

			$address=$_POST['address'];
			$First_Name=$_POST['FN'];
			$Last_Name=$_POST['LN'];
			$Contact_Number=$_POST['CN'];
			$Email=$_POST['E'];
			$Password=$_POST['P'];
			$sub=$_POST['sub'];
			$schedule=$_POST['sch'];
		


			$insertusers=mysqli_query($conn, "INSERT INTO teachers VALUES('0','$First_Name','$Last_Name','$Email','$Password','$Contact_Number','$address','$sub','$schedule')");

			if($insertusers==true){
				echo '<script>
				alert ("Registration successful!");
				window.location.href="../home/addteachers.php";
				</script> ';
			}else{
				echo '<script>
				alert ("Registration unsuccessful!");
				window.location.href="../home/addteachers.php";
				</script> ';
			}
}
?>
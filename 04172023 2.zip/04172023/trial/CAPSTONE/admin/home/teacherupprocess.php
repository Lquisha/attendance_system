<?php 
 
include "conn.php";
session_start();

if(isset($_POST['submit'])){

	$id = $_GET['id'];
	$fname = $_POST['FN'];
	$LN = $_POST['LN'];
	$E = $_POST['E'];	
	$P = $_POST['P'];
	$CN = $_POST['CN'];
	$AD = $_POST['address'];
	$sub = $_POST['sub'];
	$sch = $_POST['sch'];
	


	$updateaccount=mysqli_query($conn, "UPDATE teachers  SET firstname='$fname', lastname='$LN', email='$E', password='$P', contactnumber='$CN', address='$AD', subject='$sub', schedule='$sch' WHERE id='$id'");

	if($updateaccount==true){
		?>
		<script>
			alert ("Data change successfully!");
			window.location.href="teacherlist.php";
		</script>
		<?php
	}else{
		?>
		<script>
			alert ("Data change unsuccessfully!");
			window.location.href="teacherlist.php";
		</script>
		<?php
		
	}

}
?>
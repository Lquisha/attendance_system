<?php
include "conn.php";
$id= $_GET['id'];
$sql = "DELETE FROM students WHERE id=$id";
$result = mysqli_query($conn,$sql);
if($result){
    ?>
    <script>
        alert("delete successfully");
        window.location.href="studentlist.php";
        </script>
    <?php

}else{
    ?>
    <script>
        alert("delete unsuccessfully");
        window.location.href="studentlist.php";
        </script>
    <?php
}
?>
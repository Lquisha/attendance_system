<?php 
 
include "conn.php";
session_start();

if(isset($_POST['change_pass'])){

	$id = $_GET['id'];
	$fname = $_POST['FN'];
	$LN = $_POST['LN'];
	$E = $_POST['E'];	
	$P = $_POST['P'];
	$CN = $_POST['CN'];
	$AD = $_POST['address'];
	$sub = $_POST['sub'];
	$sch = $_POST['sch'];
	


	$updateaccount=mysqli_query($conn, "UPDATE teachers  SET firstname='$FN', lastname='$LN', firstname='$FN', email='$E', password='$P', contactnumber='$CN', address='$AD', subject='$sub', schedule='$sch' WHERE id='$id'");

	if($updateaccount==true){
		?>
		<script>
			alert ("Data change successfully!");
			window.location.href="studentaccount.php";
		</script>
		<?php
	}else{
		?>
		<script>
			alert ("Data change unsuccessfully!");
			window.location.href="studentaccount.php";
		</script>
		<?php
		
	}

}
?>
<?php 
  include "../login/conn.php";
  session_start();
  if(empty($_SESSION)){
  ?>
    <script>
      alert("session expired");
      window.location.href="../../index.php";
    </script>
    <?php
  }
else{
  $e=$_SESSION['user'];
  $get_student=mysqli_query($conn, "SELECT * FROM a_login WHERE username='$e'");
  while($row=mysqli_fetch_object($get_student))
  {
    $studentid=$row -> username;
    $name=$row -> name;
  }
}
?>
<!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>PHINMA University of Iloilo</title>
    <link rel="stylesheet" href="studentlist.css">
  
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
<div class="sidebar">
    <div class="logo-details">
        <i class='bx bx-menu' id="btn" ></i>
      <div class="logo">
       <img src="2.png" alt="logo" height="140" width="140">
    </div>
     </div>
    <ul class="nav-list">
       <li>
        <a href="adminhome.php">
          <i class='bx bx-grid-alt'></i>
          <span class="links_name">Dashboard</span>
        </a>
         <span class="tooltip">Dashboard</span>
      </li>
      <li>
       <a href="addteachers.php">
       <i class='bx bxs-user' ></i>
         <span class="links_name">Add Teachers</span>
       </a>
       <span class="tooltip">Add Teachers</span>
     </li>
     <li>
       <a href="adstudents.php">
         <i class='bx bx-user' ></i>
         <span class="links_name">Add Students</span>
       </a>
       <span class="tooltip">Add Students</span>
     </li>
     <li>
       <a href="studentlist.php">
       <i class='bx bx-list-check' ></i>
         <span class="links_name">Student's List</span>
       </a>
       <span class="tooltip">Student's List</span>
     </li>
     <li>
       <a href="teacherlist.php">
       <i class='bx bx-list-check' ></i>
         <span class="links_name">Teacher's List</span>
       </a>
       <span class="tooltip">Teacher's List</span>
     </li>
      <li class="log_out">
          <a href="logout.php">
            <i class='bx bx-log-out'></i>
            <span class="links_name">Log out</span>
          </a>
        </li>
      </ul>
  </div>
  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <span class="dashboard">Student's List</span>
      </div>
   
      <div class="profile-details">
      <span class="admin_name"><?php echo $name; ?><br><h4>admin</h4></span>
      </div>
   
      <img src="sun.png" id="icon">
     
    </nav>
 <section class="home-content">
    <div class="table">
 <table class="content-table">
        <thead>
          <tr>
      			<th>Card Number</th>
    			  <th>Student ID no.</th>
   				  <th>First Name</th>
    			  <th>Last Name</th>
  				  <th>Address</th>
  			 	  <th>Section</th>
   			     <th>Year Level</th>
    			  <th>Contact No.</th>
    			  <th>Email</th>
    			  <th>Password</th>
            <th>action</th>
          </tr>
        </thead>
        <tbody>
          <?php

           include "conn.php";

            $sql ="SELECT * FROM students ";
            $result = mysqli_query($conn, $sql);
            while ($row = mysqli_fetch_assoc($result)){
              ?>
           <tr>
             <td><?php echo $row['card_no']; ?></td>
             <td><?php echo $row['ref_no']; ?></td>
             <td><?php echo $row['firstname']; ?></td>
             <td><?php echo $row['lastname']; ?></td>
             <td><?php echo $row['address']; ?></td>
             <td><?php echo $row['section']; ?></td>
             <td><?php echo $row['yearlevel']; ?></td>
             <td><?php echo $row['contactnumber']; ?></td>
             <td><?php echo $row['email']; ?></td>
             <td><?php echo $row['password']; ?></td>
             
             <td>
               <a href="updateprofile.php?id=<?php echo $row['id']?>" class="link-dark"style="color:#7B9977;"><i class='bx bxs-edit-alt'></i></a>
                <a href="Sdelete.php?id=<?php echo $row['id']?>" class="link-dark"style="color:#7B9977;"><i class='bx bxs-trash-alt'></i></a>
             </td>
           </tr>
           <?php
              }
             ?>
        </tbody>
        </table>
</div>
</section>

  <script>
   let sidebar = document.querySelector(".sidebar");
let closeBtn = document.querySelector("#btn");


closeBtn.addEventListener("click", ()=>{
  sidebar.classList.toggle("active");
  menuBtnChange();//calling the function(optional)
});


// following are the code to change sidebar button(optional)
function menuBtnChange() {
 if(sidebar.classList.contains("open")){
   closeBtn.classList.replace("bx-menu", "bx-menu-alt-right");//replacing the iocns class
 }else {
   closeBtn.classList.replace("bx-menu-alt-right","bx-menu");//replacing the iocns class
 }
}
var icon = document.getElementById("icon");

    icon.onclick = function(){
  document.body.classList.toggle("dark-theme");
  if(document.body.classList.contains("dark-theme")){
    icon.src = "sun.png";
    }else{
   icon.src = "moon.png";
  }
  
  }
</script>

</body>
</html>


<?php
	include "conn.php";
	session_start();

		if(isset($_POST['submit'])){

			$id=$_GET['id'];

			$address=$_POST['address'];
			$First_Name=$_POST['FN'];
			$Last_Name=$_POST['LN'];
			$Student_ID=$_POST['ID'];
			$Card_Number=$_POST['C'];
			$Section=$_POST['section'];
			$Year_Level=$_POST['YL'];
			$Contact_Number=$_POST['CN'];
			$Email=$_POST['email'];
			$Password=$_POST['pass'];

				
			
			$updateaccount=mysqli_query($conn, "UPDATE students  SET password='$Password', card_no='$Card_Number', 
			firstname='$First_Name', lastname='$Last_Name', address='$address', section='$Section', yearlevel='$Year_Level', 
			contactnumber='$Contact_Number', email='$Email', ref_no='$Student_ID' WHERE id='$id'");
			

			
			if($updateaccount==true){
				?>
				<script>
				alert ("Registration successful!");
				window.location.href="../home/studentlist.php";
				</script> 
				<?php
			}else{
				?>
				<script>
				alert ("Registration unsuccessful!");
				window.location.href="../home/studentlist.php";
				</script> 
				<?php
			}
			
}

<?php 
  include "../login/conn.php";
  session_start();
  if(empty($_SESSION)){
  ?>
    <script>
      alert("session expired");
      window.location.href="index.php";
    </script>
    <?php
  }
else{
  $e=$_SESSION['email'];
  $get_teacher=mysqli_query($conn, "SELECT * FROM teachers WHERE email='$e'");
  while($row=mysqli_fetch_object($get_teacher))
  {
    $id=$row -> id;
    $email=$row -> email;
    $fname=$row -> firstname;
    $pass=$row -> password;
  }
}
?>
<!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>PHINMA University of Iloilo</title>
    <link rel="stylesheet" href="teacheraccount.css">
  
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>

    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">

     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
<div class="sidebar">
    <div class="logo-details">
        <i class='bx bx-menu' id="btn" ></i>
      <div class="logo">
       <img src="2.png" alt="logo" height="140" width="140">
    </div>
     </div>
    <ul class="nav-list">
       <li>
        <a href="adminhome.php">
          <i class='bx bx-grid-alt'></i>
          <span class="links_name">Dashboard</span>
        </a>
         <span class="tooltip">Dashboard</span>
      </li>
      <li>
        <a href="adstudents.php">
          <i class='bx bx-user'></i>
          <span class="links_name">Add Students</span>
        </a>
         <span class="tooltip">Add Students</span>
      </li>
     <li>
       <a href="studentlist.php">
       <i class='bx bx-list-check'></i>
         <span class="links_name">Student List</span>
       </a>
       <span class="tooltip">Student List</span>
     </li>
     <li>
       <a href="attendance.php">
         <i class='bx bx-calendar' ></i>
         <span class="links_name">Attendance</span>
       </a>
       <span class="tooltip">Attendance</span>
     </li>
     <li>
       <a href="teacheraccount.php">
         <i class='bx bx-mask' ></i>
         <span class="links_name">Account</span>
       </a>
       <span class="tooltip">Account</span>
     </li>
      <li class="log_out">
          <a href="logout.php">
            <i class='bx bx-log-out'></i>
            <span class="links_name">Log out</span>
          </a>
        </li>
      </ul>
  </div>
</section>
  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <span class="dashboard">Dashboard</span>
      </div>
   
      <div class="profile-details">
      <span class="admin_name"><?php echo $fname; ?><br><h4>teacher</h4></span>
      </div>
   
      <img src="sun.png" id="icon">
     
    </nav>
<section class="home-content">
<div class="container">
    <form action="accountprocess.php?id=<?php echo $id;?>" method="POST">
      <header>Password</header>
      
    
          <div class="input-box">
             <input type="password" spellcheck="false" value="<?php echo $pass; ?>"name="pass" required/>
            <i class="uil uil-eye-slash toggle"></i>
               </div>
      
		   <div class="input-field button">
          <input type="submit" value="Change" name="change_pass"/>
          </div>
         </div>
          
  
    
      </form>
    </div>

</section>

  <script>
    
  const toggle = document.querySelector(".toggle"),
  input = document.querySelector("input");

   toggle.addEventListener("click", () =>{
    if(input.type ==="password"){
       input.type = "text";
       toggle.classList.replace("uil-eye-slash", "uil-eye");
       }else{ 
      input.type = "password";     
     toggle.classList.replace("uil-eye","uil-eye-slash");
                  }
              })

   let sidebar = document.querySelector(".sidebar");
let closeBtn = document.querySelector("#btn");


closeBtn.addEventListener("click", ()=>{
  sidebar.classList.toggle("active");
  menuBtnChange();//calling the function(optional)
});


// following are the code to change sidebar button(optional)
function menuBtnChange() {
 if(sidebar.classList.contains("open")){
   closeBtn.classList.replace("bx-menu", "bx-menu-alt-right");//replacing the iocns class
 }else {
   closeBtn.classList.replace("bx-menu-alt-right","bx-menu");//replacing the iocns class
 }
}
var icon = document.getElementById("icon");

    icon.onclick = function(){
  document.body.classList.toggle("dark-theme");
  if(document.body.classList.contains("dark-theme")){
    icon.src = "sun.png";
    }else{
   icon.src = "moon.png";
  }
  
  }
</script>

</body>
</html>


<?php 
 
include "conn.php";
session_start();

if(isset($_POST['change_pass'])){

	$id = $_GET['id'];
	$pass = $_POST['pass'];
	

	$updateaccount=mysqli_query($conn, "UPDATE teachers  SET password='$pass' WHERE id='$id'");

	if($updateaccount==true){
		?>
		<script>
			alert ("Data change successfully!");
			window.location.href="teacheraccount.php";
		</script>
		<?php
	}else{
		?>
		<script>
			alert ("Data change unsuccessfully!");
			window.location.href="teacheraccount.php";
		</script>
		<?php
		
	}

}
?>
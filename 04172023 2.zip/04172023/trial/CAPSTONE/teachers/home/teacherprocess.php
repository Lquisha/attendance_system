<?php
include "../login/conn.php";
if(isset($_POST['attendance'])){
date_default_timezone_set('Asia/Manila');

$date = date("F d, Y");
$time = date('h:i:s A');
$card_num = $_POST['tap'];



$get_studentsname = mysqli_query($conn, "SELECT * FROM students where card_no='$card_num'");
$n=mysqli_num_rows($get_studentsname);

if($n >= 1){

while($row=mysqli_fetch_object($get_studentsname)){

    $fname = $row -> firstname;
    $lname = $row -> lastname;
    $section = $row -> section;
}
  
$chk_attendance = mysqli_query($conn,"SELECT * from attendance where mydate='$date' and card_no='$card_num'");

if (mysqli_num_rows($chk_attendance)) {
    $setattendance=mysqli_query($conn, "UPDATE attendance SET timeout='$time',status='Present'where mydate='$date' and card_no='$card_num'");
} else {
  $setattendance=mysqli_query($conn, "INSERT INTO attendance values('0','$date','$time','','$card_num','$fname','$lname','$section','$sub','Absent')");
}
}
if($setattendance==true){
    ?>
    <script>
       
        window.location.href="attendance.php";

    </script>
    <?php
    
}
else{
    ?>
    <script>
        alert("Account Is Not Valid");
        window.location.href="attendance.php";

    </script>
    <?php
}
}
?>
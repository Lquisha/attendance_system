<?php 
  include "../login/conn.php";
  session_start();

  date_default_timezone_set('Asia/Manila');

$date = date("F d, Y");

  if(empty($_SESSION)){
     ?>
    <script>
      alert("session expired");
      window.location.href="index.php";
    </script>
    <?php
  }
else{
  $e=$_SESSION['email'];
  $get_student=mysqli_query($conn, "SELECT * FROM teachers WHERE email='$e'");
  while($row=mysqli_fetch_object($get_student))
  {
    $studentid=$row -> email;
    $firstname=$row -> firstname;
    $sub=$row -> subject;
  }
}
?>
<?php
include "../login/conn.php";
if(isset($_POST['tap'])){
date_default_timezone_set('Asia/Manila');

$date = date("F d, Y");
$time = date('h:i:s A');
$card_num = $_POST['tap'];



$get_studentsname = mysqli_query($conn, "SELECT * FROM students where card_no='$card_num'");
$n=mysqli_num_rows($get_studentsname);

if($n >= 1){

while($row=mysqli_fetch_object($get_studentsname)){

    $fname = $row -> firstname;
    $lname = $row -> lastname;
    $section = $row -> section;
}
  
$chk_attendance = mysqli_query($conn,"SELECT * from attendance where mydate='$date' and card_no='$card_num' and subject='$sub'");

if (mysqli_num_rows($chk_attendance)) {
  $setattendance=mysqli_query($conn, "UPDATE attendance SET timeout='$time',status='Present'where mydate='$date' and card_no='$card_num'");
} else {
  $setattendance=mysqli_query($conn, "INSERT INTO attendance values('0','$date','$time','','$card_num','$fname','$lname','$section','$sub','Absent')");
}
}
if($setattendance==true){
    ?>
    <script>
       
        window.location.href="attendance.php";

    </script>
    <?php
    
}
else{
    ?>
    <script>
        alert("Account Is Not Valid");
        window.location.href="attendance.php";

    </script>
    <?php
}

}



?>
<!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>PHINMA University of Iloilo</title>
    <link rel="stylesheet" href="attendance.css">
    <script type="text/javascript" src="js/instascan.min.js"></script>
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">

     
     <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
		<link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
		<link rel="stylesheet" href="css/bootstrap.min.css">
   </head>
<body>
<div class="sidebar">
    <div class="logo-details">
        <i class='bx bx-menu' id="btn" ></i>
      <div class="logo">
       <img src="2.png" alt="logo" height="140" width="140">
    </div>
     </div>
    <ul class="nav-list">
       <li>
        <a href="teacherdashboard.php">
          <i class='bx bx-grid-alt'></i>
          <span class="links_name">Dashboard</span>
        </a>
         <span class="tooltip">Dashboard</span>
      </li>
      <li>
        <a href="adstudents.php">
          <i class='bx bx-user'></i>
          <span class="links_name">Add Students</span>
        </a>
         <span class="tooltip">Add Students</span>
      </li>
     <li>
       <a href="studentlist.php">
       <i class='bx bx-list-check'></i>
         <span class="links_name">Student List</span>
       </a>
       <span class="tooltip">Student List</span>
     </li>
     <li>
       <a href="attendance.php">
         <i class='bx bx-calendar' ></i>
         <span class="links_name">Attendance</span>
       </a>
       <span class="tooltip">Attendance</span>
     </li>
     <li>
       <a href="teacheraccount.php">
         <i class='bx bx-mask' ></i>
         <span class="links_name">Account</span>
       </a>
       <span class="tooltip">Account</span>
     </li>
      <li class="log_out">
          <a href="logout.php">
            <i class='bx bx-log-out'></i>
            <span class="links_name">Log out</span>
          </a>
        </li>
      </ul>
  </div>
  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <span class="dashboard">Attendance</span>
      </div>
   
      <div class="profile-details">
      <span class="admin_name"><?php echo $firstname; ?><br><h4>teacher</h4></span>
      </div>
   
      
		 <img src="sun.png" id="icon">
     
    </nav>
 <section class="home-content">
 <div class="container">
    <form action="attendance.php" method="POST">

    <h4>Scan For Students</h4>
    <input type="text" name="tap" style="margin-top:10px; margin-left:-50px;width:400px; height:60px; border-radius:12px;" id="text" placeholder="Scan Your Card..." required autofocus>

    <input style="visibility:hidden;" type="submit" name="attendance" >
    </form>    
    </div>
 <div class="row">
              <div class="box" style="background:#fff;border-radius: 5px; margin-top:100px; margin-left:-330px;width:400px; height: 300px;" id="divvideo">
					<center><p class="box-msg" ><i class="bx bxs-camera"></i>TAP HERE</p></center>
                    <center><video id="preview" width="90%" height="900%" style="border-radius:10px; margin-top:20px;"></video></center>
			
					

                </div>
  </section>

  <section class="home-div">

    <div class="attendance" id="divvideo" style="margin-top: 30px;">
      
       <h1> Date: <?php echo $date; ?></h1>
       <button class="btn" onclick="exportToExcel('tblexportData', 'attendance')" style="background-color:#7B9977;  font-size:16px; border: 1px solid #fff; padding: 10px 15px; border-radius: 12px; cursor: pointer;">Export</button>
       <div class="table" style=" margin-top:10px;">
        <table class="content-table" id="tblexportData">
          <thead>
            <tr>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Time In</th>
              <th>Time Out</th>
              <th>Subject</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
       


          <?php

          

          $sql ="SELECT * FROM attendance WHERE mydate='$date' and subject='$sub' ";
          $result = mysqli_query($conn, $sql);
          while ($row = mysqli_fetch_assoc($result)){
            ?>

<tbody>
       <tbody>
          <tr>
           <td><?php echo $row['fname'];?></td>
           <td><?php echo $row['lname'];?></td>
           <td><?php echo $row['timein'];?></td>
           <td><?php echo $row['timeout'];?></td>
           <td><?php echo $row['subject'];?></td>
           <td><?php echo $row['status'];?></td>
           <td> <a href="sdelete.php?id=<?php echo $row['id']?>" style="color:#7B9977;"> <i class='bx bxs-trash-alt '></i></a></td>


          </tr>
          <?php
              }
            
            ?>
       </tbody>
       </table>
</div>


    </div>

   
</section>









  <script>


let sidebar = document.querySelector(".sidebar");
let closeBtn = document.querySelector("#btn");


closeBtn.addEventListener("click", ()=>{
  sidebar.classList.toggle("active");
  menuBtnChange();//calling the function(optional)
});


// following are the code to change sidebar button(optional)
function menuBtnChange() {
 if(sidebar.classList.contains("open")){
   closeBtn.classList.replace("bx-menu", "bx-menu-alt-right");//replacing the iocns class
 }else {
   closeBtn.classList.replace("bx-menu-alt-right","bx-menu");//replacing the iocns class
 }
}



function exportToExcel(tableID, filename = ''){
    var downloadurl;
    var dataFileType = 'application/vnd.ms-excel';
    var tableSelect = document.getElementById(tableID);
    var tableHTMLData = tableSelect.outerHTML.replace(/ /g, '%20');
    
    // Specify file name
    filename = filename?filename+'.xls':'export_excel_data.xls';
    
    // Create download link element
    downloadurl = document.createElement("a");
    
    document.body.appendChild(downloadurl);
    
    if(navigator.msSaveOrOpenBlob){
        var blob = new Blob(['\ufeff', tableHTMLData], {
            type: dataFileType
        });
        navigator.msSaveOrOpenBlob( blob, filename);
    }else{
        // Create a link to the file
        downloadurl.href = 'data:' + dataFileType + ', ' + tableHTMLData;
    
        // Setting the file name
        downloadurl.download = filename;
        
        //triggering the function
        downloadurl.click();
    }
  }

  function Export()
			{
				var conf = confirm("Please confirm if you wish to proceed in exporting the attendance in to Excel File");
				if(conf == true)
				{
					window.open("export.php",'_blank');
				}
			}
		</script>				
        <script>
           let scanner = new Instascan.Scanner({ video: document.getElementById('preview')});
           Instascan.Camera.getCameras().then(function(cameras){
               if(cameras.length > 0 ){
                   scanner.start(cameras[0]);
               } else{
                   alert('No cameras found');
               }

           }).catch(function(e) {
               console.error(e);
           });

           scanner.addListener('scan',function(c){
               document.getElementById('text').value=c;
               document.forms[0].submit();
           });
        </script>
		<script type="text/javascript">
		var timestamp = '<?=time();?>';
		function updateTime(){
		  $('#time').html(Date(timestamp));
		  timestamp++;
		}
		$(function(){
		  setInterval(updateTime, 1000);
		});
		</script>
		<script src="plugins/jquery/jquery.min.js"></script>
		<script src="plugins/bootstrap/js/bootstrap.min.js"></script>
		<script src="plugins/datatables/jquery.dataTables.min.js"></script>
		<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
		<script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
		<script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>

		<script>
		  $(function () {
			$("#example1").DataTable({
			  "responsive": true,
			  "autoWidth": false,
			});
			$('#example2').DataTable({
			  "paging": true,
			  "lengthChange": false,
			  "searching": false,
			  "ordering": true,
			  "info": true,
			  "autoWidth": false,
			  "responsive": true,
			});
		  });
</script>


</body>
</html>

